[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fjson1c%2Ftelegram-raid-botnet.svg?type=shield)](https://app.fossa.com/projects/git%2Bgithub.com%2Fjson1c%2Ftelegram-raid-botnet?ref=badge_shield)

### Ботнет для рейд атак в Telegram

**Инструкция по установке: https://telegra.ph/Kak-zapustit-botnet-10-29**


## License
[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fjson1c%2Ftelegram-raid-botnet.svg?type=large)](https://app.fossa.com/projects/git%2Bgithub.com%2Fjson1c%2Ftelegram-raid-botnet?ref=badge_large)