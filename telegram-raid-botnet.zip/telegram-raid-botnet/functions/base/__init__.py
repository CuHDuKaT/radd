from .telethon import TelethonFunction
from .pyrogram import PyrogramFunction